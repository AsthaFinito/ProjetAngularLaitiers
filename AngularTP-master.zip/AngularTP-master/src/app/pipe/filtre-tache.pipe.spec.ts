import { FiltreTachePipe } from './filtre-tache.pipe';

describe('FiltreTachePipe', () => {
  it('create an instance', () => {
    const pipe = new FiltreTachePipe();
    expect(pipe).toBeTruthy();
  });
});
