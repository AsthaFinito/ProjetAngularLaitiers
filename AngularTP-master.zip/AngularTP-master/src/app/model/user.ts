export interface User {
    login:string;
    password:string;
}