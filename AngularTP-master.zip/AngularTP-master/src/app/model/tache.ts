export interface Tache {
    _id?:string;
    titre:string;
    termine:boolean;
}
